Model configuration files go in this directory. On colorlcd radios, there is
also a `models.yml` file which controls which models are shown, and in what
order they are shown.
