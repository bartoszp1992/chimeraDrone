Sound packs organised by language are stored in this directory. e.g. en, de, fr
You can also add your own model dependent sounds.
