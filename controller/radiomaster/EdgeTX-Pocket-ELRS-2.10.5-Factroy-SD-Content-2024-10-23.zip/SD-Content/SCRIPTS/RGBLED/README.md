This folder contains sample RGB Lua scripts, for radios which support this capability.
